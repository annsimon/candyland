using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Prototype
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //SpriteFont:
        SpriteFont screenFont;

        //Modelle:
        Model greenStone;
        Model grayStone;
        Model skyDome;
        Model pillar;
        Model plane;
        Model ufo;

        //Texturen:
        Texture2D domeTexture;
        Texture2D domeTextureMirror;
        Texture2D pillarTexture;
        Texture2D pillarStartTexture, pillarEndTexture;
        Texture2D planeTexture;
        Texture2D ufoTexture;

        //Player:
        Player player;
        Camera cam;

        //TranslationState translation_state;
        Stone[] stonePlaces;
        //float i = 1;

        bool playerWon = false;

        enum TranslationState
        {
            None,
            X,
            Y,
            Z
        }

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            Window.Title = "3D Game Project - Prototype";

            graphics.PreferredBackBufferHeight = 800;
            graphics.PreferredBackBufferWidth = 900;
            graphics.IsFullScreen = false;
            graphics.ApplyChanges();

            base.Initialize();
        }

        protected override void LoadContent()
        {
            player = new Player();
            cam = new Camera(Keyboard.GetState());
            player.LoadContent(Content, Keyboard.GetState());
            player.position = new Vector3(0, 5, 28);

            spriteBatch = new SpriteBatch(GraphicsDevice);

            screenFont = Content.Load<SpriteFont>("MainText");

            greenStone = Content.Load<Model>("GreenStone");
            grayStone = Content.Load<Model>("GrayStone");
            pillar = Content.Load<Model>("Pillar");
            plane = Content.Load<Model>("Plane");
            ufo = Content.Load<Model>("Ufo");

            skyDome = Content.Load<Model>("SkyDome");
            domeTexture = Content.Load<Texture2D>("domeTexture");
            domeTextureMirror = Content.Load<Texture2D>("domeTextureMirror");
            pillarTexture = Content.Load<Texture2D>("pillarTexture");
            pillarStartTexture = Content.Load<Texture2D>("pillarStartTexture");
            pillarEndTexture = Content.Load<Texture2D>("pillarEndTexture3");
            planeTexture = Content.Load<Texture2D>("planeTexture");
            ufoTexture = Content.Load<Texture2D>("ufoTexture");

            stonePlaces = new Stone[42];
            //stonePlaces[1] = new Stone(0, 0, 28); //Start
            stonePlaces[2] = new Stone(8, 0, 36);
            stonePlaces[3] = new Stone(0, 0, 44);
            stonePlaces[4] = new Stone(-36, 0, 72);
            stonePlaces[5] = new Stone(-44, 0, 72);
            stonePlaces[6] = new Stone(-52, 0, 72);
            stonePlaces[7] = new Stone(0, 0, 12);
            stonePlaces[8] = new Stone(-8, 0, 20);
            stonePlaces[9] = new Stone(32, 0, 28);
            stonePlaces[10] = new Stone(32, 0, 36);
            stonePlaces[11] = new Stone(32, 0, 20);
            stonePlaces[12] = new Stone(32, 0, 12);
            stonePlaces[13] = new Stone(32, 0, 4);
            stonePlaces[14] = new Stone(40, 0, 36); 
            stonePlaces[15] = new Stone(48, 0, 36); 
            stonePlaces[16] = new Stone(120, 0, 28); 
            stonePlaces[17] = new Stone(120, 0, 20);
            stonePlaces[18] = new Stone(120, 0, 12);
            stonePlaces[19] = new Stone(40, 0, -14);
            stonePlaces[20] = new Stone(-8, 0, -14);
            stonePlaces[21] = new Stone(64, 0, -22); 
            stonePlaces[22] = new Stone(120, 0, -112);
            stonePlaces[23] = new Stone(120, 0, 132); 
            stonePlaces[24] = new Stone(112, 0, 132);
            stonePlaces[25] = new Stone(120, 0, 124);
            stonePlaces[26] = new Stone(-104, 0, 124); 
            stonePlaces[27] = new Stone(-116, 0, -50); 
            stonePlaces[28] = new Stone(-116, 0, -42); 
            stonePlaces[29] = new Stone(-100, 0, -58); 
            stonePlaces[30] = new Stone(-92, 0, -58); 
            stonePlaces[31] = new Stone(-16, 0, -80); 
            stonePlaces[32] = new Stone(-156, 0, 160); 
            stonePlaces[33] = new Stone(-56, 0, -116); 
            stonePlaces[34] = new Stone(-64, 0, -116);
            //Green
            stonePlaces[35] = new Stone(-88, 0, 36, StoneType.Green);
            stonePlaces[36] = new Stone(112, 0, -112, StoneType.Green); 
            stonePlaces[37] = new Stone(112, 0, 64, StoneType.Green);
            stonePlaces[38] = new Stone(56, 0, 4, StoneType.Green);
            stonePlaces[39] = new Stone(40, 0, -50, StoneType.Green);
            stonePlaces[40] = new Stone(-108, 0, -18, StoneType.Green);
            stonePlaces[41] = new Stone(-156, 0, -72, StoneType.Green);

            //stonePlaces[42] = new Stone(-156, 0, 152); //End
            //translation_state = TranslationState.None;
        }

        protected override void UnloadContent()
        {
        }


        protected override void Update(GameTime gameTime)
        {
            if ( Keyboard.GetState().IsKeyDown( Keys.Escape ) )
                this.Exit();

            if (!playerWon)
            {
                cam.GetCurrentCamera(Keyboard.GetState());
                if (!cam.overview) player.updatePosition(Keyboard.GetState(), gameTime);
                cam.Update(graphics, player);
                if (player.crash)
                    cam.staticCam = true;
                if (!player.crash)
                {
                    for (int i = 2; i < 35; i++)
                        player.Collide(stonePlaces[i].Position, 1);
                    for (int i = 35; i < 42; i++)
                    {
                        if (!stonePlaces[i].hasCollided())
                            if (player.Collide(stonePlaces[i].Position, 2))
                                stonePlaces[i].collided(true);
                        stonePlaces[i].updatePosition(Keyboard.GetState(), gameTime, player.yaw);
                    }
                }

                if (player.position.X >= -159 && player.position.X <= -153 && player.position.Z <= 155 && player.position.Z >= 149)
                    playerWon = true;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            Matrix world;

            if( cam.staticCam )
                world =  Matrix.CreateTranslation(0, -0.7f, 0) * Matrix.CreateScale(10) * Matrix.CreateTranslation(new Vector3(player.position.X,5,player.position.Z));
            else
                world = Matrix.CreateTranslation(0, -0.7f, 0) * Matrix.CreateScale(10) * Matrix.CreateTranslation(player.position); 
            GraphicsDevice.DepthStencilState = DepthStencilState.None;
            DrawModel(skyDome, world, domeTexture, cam);
            GraphicsDevice.DepthStencilState = DepthStencilState.Default;

            world = Matrix.CreateScale(50) * Matrix.CreateTranslation(new Vector3(0, -50, 0));
            DrawModel(plane, world, planeTexture, cam);

            world = Matrix.CreateRotationY(player.yaw) * Matrix.CreateTranslation(new Vector3(0, -2f, 0))  * Matrix.CreateTranslation(player.position);
            DrawModel(ufo, world, ufoTexture, cam);

            for (int j = 2; j < stonePlaces.Length; j++)
            {
                world = Matrix.CreateTranslation(stonePlaces[j].Position);
                if (stonePlaces[j].Type == StoneType.Green)
                {
                    DrawModel(greenStone, world, cam);
                    world = Matrix.CreateTranslation(stonePlaces[j].PillarPosition);
                    DrawModel(pillar, world, pillarTexture, cam);
                }
                else
                {
                    DrawModel(grayStone, world, cam);
                    DrawModel(pillar, world, pillarTexture, cam);

                    world = Matrix.CreateTranslation(stonePlaces[j].Position + new Vector3(8, 0, 0));
                    DrawModel(pillar, world, pillarTexture, cam);
                    world = Matrix.CreateTranslation(stonePlaces[j].Position + new Vector3(0, 0, 8));
                    DrawModel(pillar, world, pillarTexture, cam);
                    world = Matrix.CreateTranslation(stonePlaces[j].Position + new Vector3(0, 0, -8));
                    DrawModel(pillar, world, pillarTexture, cam);
                    world = Matrix.CreateTranslation(stonePlaces[j].Position + new Vector3(-8, 0, 0));
                    DrawModel(pillar, world, pillarTexture, cam);
                }
            }

            world = Matrix.CreateTranslation(new Vector3(0, 0, 28));
            DrawModel(pillar, world, pillarStartTexture, cam);
            world = Matrix.CreateTranslation(new Vector3(-156, 0, 152));
            DrawModel(pillar, world, pillarEndTexture, cam);

            spriteBatch.Begin();

            spriteBatch.DrawString(screenFont, "Zeit: " + Math.Round(gameTime.TotalGameTime.TotalSeconds, 1), new Vector2(5f, 5f), Color.White);
            spriteBatch.DrawString(screenFont, "Maximale Flugzeit: " + player.maximumFlightTime + "s", new Vector2(5f, 20f), Color.White);
            spriteBatch.DrawString(screenFont, "Aktuelle Flugzeit: " + Math.Round(player.currentFlightTime, 1) + "s", new Vector2(5f, 35f), Color.White);
            if (player.crash)
                spriteBatch.DrawString(screenFont, "Verloren, du bist zu lang geflogen!", new Vector2(150, 150), Color.White);
            if(playerWon)
                spriteBatch.DrawString(screenFont, "Gewonnen, du hast das Ziel erreicht!", new Vector2(150, 150), Color.Black);
            spriteBatch.End();

            GraphicsDevice.DepthStencilState = DepthStencilState.Default;
            GraphicsDevice.BlendState = BlendState.Opaque;

            base.Draw(gameTime);
        }

        /// <summary>
        /// Draws the 3D specified model.
        /// </summary>
        /// <param name="model">The 3D model being drawn.</param>
        /// <param name="world">Transformation matrix for world coords.</param>
        /// <param name="texture">Texture used for the drawn 3D model.</param>
        void DrawModel(Model model, Matrix world, Texture2D texture, Camera cam)
        {
            // Copy any parent transforms.
            Matrix[] transforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(transforms);
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect be in mesh.Effects)
                {
                    be.EnableDefaultLighting();
                    be.Projection = cam.GetProjectionMatrix();
                    be.View = cam.GetViewMatrix();
                    be.World = transforms[mesh.ParentBone.Index] * world;
                    be.Texture = texture;
                    be.TextureEnabled = true;
                }
                mesh.Draw();
            }
        }

        /// <summary>
        /// Draws the 3D specified model.
        /// </summary>
        /// <param name="model">The 3D model being drawn.</param>
        /// <param name="world">Transformation matrix for world coords.</param>
        /// <param name="texture">Texture used for the drawn 3D model.</param>
        void DrawModel(Model model, Matrix world, Camera cam)
        {
            // Copy any parent transforms.
            Matrix[] transforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(transforms);
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect be in mesh.Effects)
                {
                    be.EnableDefaultLighting();
                    be.Projection = cam.GetProjectionMatrix();
                    be.View = cam.GetViewMatrix();
                    be.World = transforms[mesh.ParentBone.Index] * world;
                }
                mesh.Draw();
            }
        }
    }
}
