﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// Nicht vergessen vorher die DLL zu den Referenzen hinzuzufügen
using MediBalancePro;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Diese Klasse übernimmt die Kommunikation mit der Hardware
        /// </summary>
        DeviceManager _mediBalanceProDeviceManager;

        System.Timers.Timer _drawTimer;
        int _nbDataPointsSinceStart = 0;
        PointF _currentFilteredValue;

        public Form1()
        {
            InitializeComponent();
            //_drawTimer = new System.Timers.Timer( 33 );
            _drawTimer = new System.Timers.Timer(100);
            _drawTimer.Elapsed += new System.Timers.ElapsedEventHandler(_drawTimer_Elapsed);
            _currentFilteredValue = PointF.Empty;
        }

        void _drawTimer_Elapsed( object sender, System.Timers.ElapsedEventArgs e )
        {
            // Sorgt dafür, dass das Fenster neu gemalt werden muss.
            this.Invalidate();
        }

        protected override void OnHandleCreated( EventArgs e )
        {
            base.OnHandleCreated( e );

            
            // Die Initialisierung des DeviceManagers benötigt einen gültigen windowHandle, um sich beim Betriebssystem für das Empfangen der nötigen Window-Messages zu registrieren.
            // Deswegen passiert das hier, und nicht im Konstruktor. Könnte man auch irgendwo anders machen, solang this.Handle gültig ist.
            _mediBalanceProDeviceManager = new DeviceManager();
            _mediBalanceProDeviceManager.Connect( this.Handle );

            // Erzeugt ein Tiefpass-Filterobjekt mit der Bufferlänge 20.
            _mediBalanceProDeviceManager.DataFilter = new DF_DepthPass( 20 );

            // Diese Event wird immer ausgelöst, wenn neue Messdaten von der Hardware kommen. Diese Daten sind auch in den Eventargs zu finden.
            _mediBalanceProDeviceManager.NewData += new DeviceManager.NewDataEventHandler( _dvMgr_NewData );

            // Der Name sagt alles. Wird ausgelöst, wenn die Hardware entfernt wurde.
            _mediBalanceProDeviceManager.DeviceRemoved += new EventHandler( _dvMgr_DeviceRemoved );


            _drawTimer.Start();
        }

        void _dvMgr_DeviceRemoved( object sender, EventArgs e )
        {
            _nbDataPointsSinceStart = 0;
        }

        void _dvMgr_NewData( object sender, NewDataEventArgs args )
        {
            _nbDataPointsSinceStart++;

            // Wenn ein DataFilter-Objekt im DeviceManager vorhanden ist, dann kann man sich hier einen gefilterten Wert holen.
            if( args.FilteredDataPresent )
                _currentFilteredValue = args.FilteredData;
            else
                _currentFilteredValue = PointF.Empty;
        }

        protected override void WndProc( ref Message m )
        {
            // Muss aufgerufen werden, um automatisch zu erkennen wenn die Hardware angeschlossen oder entfernt wurde.
            if( _mediBalanceProDeviceManager != null )
                _mediBalanceProDeviceManager.wndproc( m );

            base.WndProc( ref m );
        }

        bool _paintAllBufferedValues = true;

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(this.BackColor);

            if (_mediBalanceProDeviceManager.IsCalibrating )
            {
                e.Graphics.DrawString(string.Format("Device is calibrating"), this.Font, Brushes.Black, 5, _buttonCalibrate.Height+10, StringFormat.GenericDefault);
                return;
            }

            if (_paintAllBufferedValues)
            {
                int nbPoints = 0;
                int nbFilteredPoints = 0;
                {
                    Pen pen = new Pen(Color.Red, 4.0f);
                    PointF[] pointBuffer = _mediBalanceProDeviceManager.GetAllValuesInBuffer();
                    nbPoints = pointBuffer.Length;
                    
                    if (pointBuffer.Length == 0)
                    {
                        return;
                    }
                    // berechnet einen Punkt, der im Intervall [0,1] die verhältnismäßig gleiche Position hat wie der Eingabepunkt im eingegebenen Bounds-Rectangle
                    PointF p0 = _mediBalanceProDeviceManager.normalizePoint(pointBuffer[0], 20.0f, _mediBalanceProDeviceManager.HardwareBounds);
                    p0.X *= this.Width;
                    p0.Y *= this.Height;

                    PointF p1 = p0;
                    for (int i = 1; i < pointBuffer.Length; i++)
                    {
                        p1 = _mediBalanceProDeviceManager.normalizePoint(pointBuffer[i], 20.0f, _mediBalanceProDeviceManager.HardwareBounds);
                        p1.X *= this.Width;
                        p1.Y *= this.Height;

                        e.Graphics.DrawLine(pen, p0, p1);
                        p0 = p1;
                    }
                }
                {
                    Pen pen = new Pen(Color.Blue, 2.0f);
                    PointF[] pointBuffer = _mediBalanceProDeviceManager.GetAllFilteredValuesInBuffer();
                    nbFilteredPoints = pointBuffer.Length;

                    if (pointBuffer.Length == 0)
                    {
                        return;
                    }
                    // berechnet einen Punkt, der im Intervall [0,1] die verhältnismäßig gleiche Position hat wie der Eingabepunkt im eingegebenen Bounds-Rectangle
                    PointF p0 = _mediBalanceProDeviceManager.normalizePoint(pointBuffer[0], 20.0f, _mediBalanceProDeviceManager.HardwareBounds);
                    p0.X *= this.Width;
                    p0.Y *= this.Height;

                    PointF p1 = p0;
                    for (int i = 1; i < pointBuffer.Length; i++)
                    {
                        p1 = _mediBalanceProDeviceManager.normalizePoint(pointBuffer[i], 20.0f, _mediBalanceProDeviceManager.HardwareBounds);
                        p1.X *= this.Width;
                        p1.Y *= this.Height;

                        e.Graphics.DrawLine(pen, p0, p1);
                        p0 = p1;
                    }
                }

                e.Graphics.DrawString(string.Format("Paint AllBufferedValues: BufferSize: {0}/{1}", nbPoints, nbFilteredPoints), this.Font, Brushes.Black, 5, _buttonCalibrate.Height + 10, StringFormat.GenericDefault);
            }
            else
            {
                // holt den gerade aktuellsten Punkt
                PointF dataPoint = _mediBalanceProDeviceManager.GetCurrentValueInBuffer();

                // Wenn noch keine Daten gemessen wurden wird ein PointF( float.NaN, float.NaN ) zurückgegeben.
                if (float.IsNaN(dataPoint.X) || float.IsNaN(dataPoint.Y))
                {
                    base.OnPaint(e);
                    return;
                }

                // berechnet einen Punkt, der im Intervall [0,1] die verhältnismäßig gleiche Position hat wie der Eingabepunkt im eingegebenen Bounds-Rectangle
                PointF drawPoint = _mediBalanceProDeviceManager.normalizePoint(dataPoint, 20.0f, _mediBalanceProDeviceManager.HardwareBounds);
                int w = this.Width / 20;
                int h = this.Height / 20;
                e.Graphics.FillEllipse(Brushes.Red, drawPoint.X * this.Width - w / 2, drawPoint.Y * this.Height - h / 2, w, h);

                // Wenn gefilterte Daten vorhanden sind, sollen die auch noch dargestellt werden
                if (_currentFilteredValue != PointF.Empty)
                {
                    drawPoint = _mediBalanceProDeviceManager.normalizePoint(_currentFilteredValue, 20.0f, _mediBalanceProDeviceManager.HardwareBounds);
                    w = this.Width / 25;
                    h = this.Height / 25;
                    e.Graphics.FillEllipse(Brushes.Blue, drawPoint.X * this.Width - w / 2, drawPoint.Y * this.Height - h / 2, w, h);
                }

                e.Graphics.DrawString(string.Format("Paint only CurrentValue: {0:N1}|{1:N1} - NbData since start: {2}", dataPoint.X, dataPoint.Y, _nbDataPointsSinceStart), this.Font, Brushes.Black, 5, _buttonCalibrate.Height+10, StringFormat.GenericDefault);
            }
            
            base.OnPaint( e );
        }

        private void _buttonCalibrate_Click(object sender, EventArgs e)
        {

            if (_mediBalanceProDeviceManager != null && !_mediBalanceProDeviceManager.IsCalibrating)
            {
                _mediBalanceProDeviceManager.startCalibrate();
            }
        }

        private void _buttonView_Click(object sender, EventArgs e)
        {
            _paintAllBufferedValues = !_paintAllBufferedValues;
        }
    }
}
