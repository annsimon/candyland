﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Prototype
{
    public enum StoneType
    {
        Green,
        Gray
    }

    public class Stone
    {
        public float X
        {
            get
            {
                return Position.X;
            }
            set
            {
                Position = new Vector3(value, Position.Y, Position.Z);
            }
        }
        public float Y
        {
            get
            {
                return Position.Y;
            }
            set
            {
                Position = new Vector3(Position.X, value, Position.Z);
            }
        }
        public float Z
        {
            get
            {
                return Position.Z;
            }
            set
            {
                Position = new Vector3(Position.X, Position.Y, value);
            }
        }
        public Vector3 Position {get; set; }
        public float PillarX
        {
            get
            {
                return PillarPosition.X;
            }
            set
            {
                PillarPosition = new Vector3(value, PillarPosition.Y, PillarPosition.Z);
            }
        }
        public float PillarY
        {
            get
            {
                return PillarPosition.Y;
            }
            set
            {
                PillarPosition = new Vector3(PillarPosition.X, value, PillarPosition.Z);
            }
        }
        public float PillarZ
        {
            get
            {
                return PillarPosition.Z;
            }
            set
            {
                PillarPosition = new Vector3(PillarPosition.X, PillarPosition.Y, value);
            }
        }
        public Vector3 PillarPosition {get; set; }

        public StoneType Type { get; set; }

        bool m_collided = false;
        bool fall = false;
        bool moveBack = false;

        public Stone(float x, float y, float z)
        {
            Type = StoneType.Gray;
            Position = new Vector3(x, y, z);
            PillarPosition = new Vector3(x,y,z);
        }

        public Stone(float x, float y, float z, StoneType type)
            : this(x, y, z)
        {
            Type = StoneType.Green;
        }

        public void collided( bool collided )
        {
            m_collided = collided;
            moveBack = true;
        }

        public bool hasCollided()
        {
            return m_collided;
        }

        public void updatePosition(KeyboardState keyboardState, GameTime gameTime, float playerYaw)
        {
            if (fall)
            {
                if (Y > -50.0f)
                    Y -= 0.5f;
                return;
            }
            if (moveBack)
            {
                Matrix backwardMovement = Matrix.CreateRotationY(playerYaw);
                Vector3 v = new Vector3(0, 0, 20);
                v = Vector3.Transform(v, backwardMovement);
                Z += v.Z;
                X += v.X;
                moveBack = false;
                fall = true;
                return;
            }
        }
    }
}
