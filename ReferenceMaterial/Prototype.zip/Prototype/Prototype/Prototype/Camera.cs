﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Prototype
{
    class Camera
    {
        Matrix view;
        Matrix proj;

        // Set the direction the camera points without rotation.
        Vector3 cameraReference = new Vector3(0, 0, 10);

        Vector3 thirdPersonReference = new Vector3(0, 2, -10);

        // Set field of view of the camera in radians (pi/4 is 45 degrees).
        static float viewAngle = MathHelper.PiOver4;

        // Set distance from the camera of the near and far clipping planes.
        //static float nearClip = 5.0f;
        static float nearClip = 1.0f;
        static float farClip = 2000.0f;

        // Set the camera state, avatar's center, first-person, third-person.
        public int state = 2;
        bool stateKeyDown;
        public bool overview = false;

        public bool staticCam = false;

        // the old keystate
        KeyboardState oldKS;

        public Camera(KeyboardState currentKeyState)
        {
            oldKS = currentKeyState;
        }

        /// <summary>
        /// Gets the current camera state.
        /// </summary>
        public void GetCurrentCamera(KeyboardState currentKeyState)
        {
            // Toggle the state of the camera.
            if (currentKeyState.IsKeyDown(Keys.M) && oldKS.IsKeyUp(Keys.M))
                overview = !overview;
            if (oldKS.IsKeyDown(Keys.Tab) && currentKeyState.IsKeyUp(Keys.Tab))
            {
                stateKeyDown = true;
            }
            else if (stateKeyDown == true)
            {
                stateKeyDown = false;
                state += 1;
                state %= 3;
            }
            oldKS = currentKeyState;
        }

        public void Update(GraphicsDeviceManager graphics, Player player)
        {
            if (overview)
            {
                UpdateCameraOverview(graphics);
                return;
            }
            switch (state)
            {
                default:
                case 0:
                    UpdateCamera(graphics, player);
                    break;
                case 1:
                    UpdateCameraFirstPerson(graphics, player);
                    break;
                case 2:
                    UpdateCameraThirdPerson(graphics, player);
                    break;
            }
        }

        /// <summary>
        /// Updates the camera when it's in the 1st person state.
        /// </summary>
        public void UpdateCamera( GraphicsDeviceManager graphics, Player player )
        {
            if (staticCam) return;

            // Calculate the camera's current position.
            Vector3 cameraPosition = player.position;

            Matrix rotationMatrix = Matrix.CreateRotationY(player.yaw);

            // Create a vector pointing the direction the camera is facing.
            Vector3 transformedReference = Vector3.Transform(cameraReference, rotationMatrix);

            // Calculate the position the camera is looking at.
            Vector3 cameraLookat = cameraPosition + transformedReference;

            // Set up the view matrix and projection matrix.
            view = Matrix.CreateLookAt(cameraPosition, cameraLookat, new Vector3(0.0f, 1.0f, 0.0f));

            Viewport viewport = graphics.GraphicsDevice.Viewport;
            float aspectRatio = (float)viewport.Width / (float)viewport.Height;

            proj = Matrix.CreatePerspectiveFieldOfView(viewAngle, aspectRatio, nearClip, farClip);
        }

        /// <summary>
        /// Updates the camera when it's in the 1st person offset state.
        /// </summary>
        public void UpdateCameraFirstPerson(GraphicsDeviceManager graphics, Player player)
        {
            if (staticCam) return;

            Matrix rotationMatrix = Matrix.CreateRotationY(player.yaw);

            // Transform the head offset so the camera is positioned properly relative to the avatar.
            Vector3 headOffset = Vector3.Transform(player.headOffset, rotationMatrix);

            // Calculate the camera's current position.
            Vector3 cameraPosition = player.position + headOffset;

            // Create a vector pointing the direction the camera is facing.
            Vector3 transformedReference = Vector3.Transform(cameraReference, rotationMatrix);

            // Calculate the position the camera is looking at.
            Vector3 cameraLookat = transformedReference + cameraPosition;

            // Set up the view matrix and projection matrix.
            view = Matrix.CreateLookAt(cameraPosition, cameraLookat, new Vector3(0.0f, 1.0f, 0.0f));

            Viewport viewport = graphics.GraphicsDevice.Viewport;
            float aspectRatio = (float)viewport.Width / (float)viewport.Height;

            proj = Matrix.CreatePerspectiveFieldOfView(viewAngle, aspectRatio, nearClip, farClip);

        }

        /// <summary>
        /// Updates the camera when it's in the 3rd person state.
        /// </summary>
        public void UpdateCameraThirdPerson(GraphicsDeviceManager graphics, Player player)
        {
            if (staticCam) return;

            Matrix rotationMatrix = Matrix.CreateRotationY(player.yaw);

            // Create a vector pointing the direction the camera is facing.
            Vector3 transformedReference = Vector3.Transform(thirdPersonReference, rotationMatrix);

            // Calculate the position the camera is looking from.
            Vector3 cameraPosition = transformedReference + player.position;

            // Set up the view matrix and projection matrix.
            view = Matrix.CreateLookAt(cameraPosition, player.position, new Vector3(0.0f, 1.0f, 0.0f));

            Viewport viewport = graphics.GraphicsDevice.Viewport;
            float aspectRatio = (float)viewport.Width / (float)viewport.Height;

            proj = Matrix.CreatePerspectiveFieldOfView(viewAngle, aspectRatio, nearClip, farClip);
        }

        public void UpdateCameraOverview(GraphicsDeviceManager graphics)
        {
            // position the camera is looking from.
            Vector3 cameraPosition = new Vector3(-20, 400, 20);

            // Set up the view matrix and projection matrix.
            view = Matrix.CreateLookAt(cameraPosition, new Vector3(-20.0f, 0.0f, 20.0f), new Vector3(0.0f, 0.0f, 1.0f));

            Viewport viewport = graphics.GraphicsDevice.Viewport;
            float aspectRatio = (float)viewport.Width / (float)viewport.Height;

            proj = Matrix.CreatePerspectiveFieldOfView(viewAngle, aspectRatio, nearClip, farClip);
        }

        public Matrix GetProjectionMatrix() { return proj; }
        public Matrix GetViewMatrix() { return view; }
    }
}
