?using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace MediBalancePro
{
    public abstract class DataFilters
    {
        public abstract void Reset();
        public abstract PointF ProcessData( PointF pt );
    }

    // ------------------------------------------------------------------------

    public class DF_DepthPass : DataFilters
    {
        public readonly int BufferLength;

        private Queue<PointF> _buffer;
        private PointF _currentSum;

        public DF_DepthPass( int bufferLength )
            : base()
        {
            BufferLength = bufferLength;
            _buffer = new Queue<PointF>();
            _currentSum = new PointF();
        }

        public override void Reset()
        {
            _buffer.Clear();
            _currentSum.X = _currentSum.Y = 0;
        }

        object processDataLocker = new object();
        public override PointF ProcessData( PointF pt )
        {
            lock( processDataLocker )
            {
                _currentSum.X += pt.X;
                _currentSum.Y += pt.Y;

                _buffer.Enqueue( pt );
                if( _buffer.Count > BufferLength )
                {
                    PointF pt2 = _buffer.Dequeue();
                    _currentSum.X -= pt2.X;
                    _currentSum.Y -= pt2.Y;
                }

                return new PointF( _currentSum.X / _buffer.Count, _currentSum.Y / _buffer.Count );
            }
        }
    }
}
