﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Prototype
{
    class Player
    {
        // Set the avatar position and rotation variables.
        public Vector3 position = new Vector3(0, 0, -50);
        public Vector3 headOffset = new Vector3(0, 10, 0);
        public float yaw;
        public float maximumFlightTime = 5.5f; //in seconds
        public float currentFlightTime = 0; 
        public bool currentlyFlying = false; //wenn der spieler mit einem stein kollidiert, kann die bewegung hiermit angehalten werden
        public bool crash = false; //crash wenn der spieler zu lang fliegt //reicht eigentlich aus, damit er verlieren kann.

        // Move back for a certain amount
        bool moveBack = false;
        // Move on for a certain amount
        bool moveOn = false;
        // Falling down
        bool fall = false;

        // Set rates in world units per 1/60th second (the default fixed-step interval).
        float rotationSpeed = MathHelper.ToRadians(90) / 20f;
        float forwardSpeed = 50f / 60f;

        // animations caused by movement
        int movementTimer = 0;
        bool rotateLeft = false;
        bool rotateRight = false;

        // hovering animation of model
        int hoverTimer = 60;
        bool movingDown = true;

        // the model
        public Model model;

        // the old keystate
        KeyboardState oldKS;

        public Player()
        {
        }

        public void LoadContent( ContentManager Content, KeyboardState oldKeyState )
        {
            model = Content.Load<Model>("GreenStone");
            oldKS = oldKeyState;
        }

        /// <summary>
        /// Update the position and direction of the avatar.
        /// </summary>
        public void updatePosition( KeyboardState keyboardState, GameTime gameTime)
        {
            if (fall)
            {
                position.Y -= 0.5f;
                return;
            }
            if (movingDown)
            {
                position.Y -= 0.005f;
                hoverTimer--;
                if (hoverTimer < 1)
                {
                    hoverTimer = 60;
                    movingDown = !movingDown;
                }
            }
            else
            {
                position.Y += 0.005f;
                hoverTimer--;
                if (hoverTimer < 1)
                {
                    hoverTimer = 60;
                    movingDown = !movingDown;
                }
            }
            if (moveBack)
            {
                Matrix backwardMovement = Matrix.CreateRotationY(yaw);
                Vector3 v = new Vector3(0, 0, -0.6f);
                v = Vector3.Transform(v, backwardMovement);
                position.Z += v.Z;
                position.X += v.X;
                moveBack = false;
                currentlyFlying = false;
                return;
            }
            if (moveOn)
            {
                Matrix forwardMovement = Matrix.CreateRotationY(yaw);
                Vector3 v = new Vector3(0, 0, 7.0f/20.0f);
                v = Vector3.Transform(v, forwardMovement);
                position.Z += v.Z;
                position.X += v.X;

                movementTimer--;
                if (movementTimer < 1)
                    moveOn = false;
                
                currentlyFlying = false;
                return;
            }
            if (rotateLeft)
            {
                yaw += rotationSpeed;
                movementTimer--;
                if (movementTimer < 1)
                    rotateLeft = false;
            }
            if (rotateRight)
            {
                yaw -= rotationSpeed;
                movementTimer--;
                if (movementTimer < 1)
                    rotateRight = false;
            }

            if ( ( ( keyboardState.IsKeyDown(Keys.Left) && oldKS.IsKeyUp(Keys.Left) ) || 
                    ( keyboardState.IsKeyDown(Keys.A) && oldKS.IsKeyUp(Keys.A) ) )
                && (!keyboardState.IsKeyDown(Keys.Up) 
                &&  !keyboardState.IsKeyDown(Keys.W) 
                && !currentlyFlying) )
            {
                // Rotate left.
                rotateLeft = true;
                movementTimer = 20;
            }
            if (((keyboardState.IsKeyDown(Keys.Right) && oldKS.IsKeyUp(Keys.Right)) ||
                    (keyboardState.IsKeyDown(Keys.D) && oldKS.IsKeyUp(Keys.D)))
                && (!keyboardState.IsKeyDown(Keys.Up) 
                && !keyboardState.IsKeyDown(Keys.W) 
                && !currentlyFlying))
            {
                // Rotate right.
                rotateRight = true;
                movementTimer = 20;
            }
            if (keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.W) || currentlyFlying)
            {
                Matrix forwardMovement = Matrix.CreateRotationY(yaw);
                Vector3 v = new Vector3(0, 0, forwardSpeed);
                v = Vector3.Transform(v, forwardMovement);
                position.Z += v.Z;
                position.X += v.X;
                currentlyFlying = true;
            }
            /*
            if (keyboardState.IsKeyDown(Keys.Down) || keyboardState.IsKeyDown(Keys.S) )
            {
                Matrix forwardMovement = Matrix.CreateRotationY(yaw);
                Vector3 v = new Vector3(0, 0, -forwardSpeed);
                v = Vector3.Transform(v, forwardMovement);
                position.Z += v.Z;
                position.X += v.X;
                currentlyFlying = false;
            }
            */

            if (currentlyFlying)
            {
                currentFlightTime += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (currentFlightTime >= maximumFlightTime)
                {
                    fall = true;
                    crash = true;
                }
            }
            else
            {
                currentFlightTime = 0;
            }

            oldKS = keyboardState;
        }

        /// <summary>
        /// Check for collision with the model passed in the model parameter
        /// Collision types: 1 for collision with stone, 2 for collision with movable stone,
        /// 3 for collision with bonus points, 4 for collision with "hole", 
        /// 5 for collision with bounds of map.
        /// </summary>
        public bool Collide(Vector3 position2, int collisionType)
        {
            // Check whether the bounding boxes of the two cubes intersect.
            BoundingBox model2BoundingBox = new BoundingBox();
            model2BoundingBox.Min = position2 - new Vector3(7.8f, 7.8f, 7.8f);
            model2BoundingBox.Max = position2 + new Vector3(7.8f, 7.8f, 7.8f);

            for (int j = 0; j < model.Meshes.Count; j++)
            {
                BoundingSphere modelBoundingSphere = model.Meshes[j].BoundingSphere;
                // scale the bounding sphere to the desired size
                float scale = 0.005f;
                modelBoundingSphere.Radius *= scale;
                // translate to correct position
                modelBoundingSphere.Center = position;

                ContainmentType type = model2BoundingBox.Contains(modelBoundingSphere);
                if (type.Equals(ContainmentType.Contains)
                    && collisionType == 4)
                {
                    // to do: stop updating camera, so the player's avatar falls visibly
                    fall = true;
                    return true;
                }
                else if (type.Equals(ContainmentType.Disjoint)
                    && collisionType == 5)
                {
                    // to do: stop updating camera, so the player's avatar falls visibly
                    fall = true;
                    return true;
                }
                else if (modelBoundingSphere.Intersects(model2BoundingBox))
                {
                    // do something
                    switch (collisionType)
                    {
                        case 1: moveBack = true; break;
                        case 2: moveOn = true; movementTimer = 20; break;
                        case 3: break;
                    }
                    return true;
                }
            }
            return false;
        }
    }
}
