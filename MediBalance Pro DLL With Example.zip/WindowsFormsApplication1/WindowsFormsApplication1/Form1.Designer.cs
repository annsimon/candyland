﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( _mediBalanceProDeviceManager != null )
            {
                _mediBalanceProDeviceManager.Dispose();
                _mediBalanceProDeviceManager = null;
            }
            
            if( disposing && ( components != null ) )
            {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._buttonCalibrate = new System.Windows.Forms.Button();
            this._buttonView = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // _buttonCalibrate
            // 
            this._buttonCalibrate.Location = new System.Drawing.Point(2, 0);
            this._buttonCalibrate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._buttonCalibrate.Name = "_buttonCalibrate";
            this._buttonCalibrate.Size = new System.Drawing.Size(100, 28);
            this._buttonCalibrate.TabIndex = 0;
            this._buttonCalibrate.Text = "Kalibrieren";
            this._buttonCalibrate.UseVisualStyleBackColor = true;
            this._buttonCalibrate.Click += new System.EventHandler(this._buttonCalibrate_Click);
            // 
            // _buttonView
            // 
            this._buttonView.Location = new System.Drawing.Point(109, 0);
            this._buttonView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._buttonView.Name = "_buttonView";
            this._buttonView.Size = new System.Drawing.Size(100, 28);
            this._buttonView.TabIndex = 1;
            this._buttonView.Text = "Ansicht";
            this._buttonView.UseVisualStyleBackColor = true;
            this._buttonView.Click += new System.EventHandler(this._buttonView_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 603);
            this.Controls.Add(this._buttonView);
            this.Controls.Add(this._buttonCalibrate);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _buttonCalibrate;
        private System.Windows.Forms.Button _buttonView;
    }
}

